package com.greglturnquist.hackingspringbootch6reactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackingSpringBootChapter6ApIsApplicationTests {

	@Test
	void contextLoads() {
	}

}
