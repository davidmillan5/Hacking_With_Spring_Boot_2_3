package com.greglturnquist.hackingspringbootch6reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackingSpringBootChapter6ApIsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackingSpringBootChapter6ApIsApplication.class, args);
	}

}
